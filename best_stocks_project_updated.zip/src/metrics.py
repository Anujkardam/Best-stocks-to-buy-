# metrics.py
# Functions for calculating annual return, volatility, and Sharpe ratio.
